<?php

declare(strict_types=1);

namespace Ddeboer\Imap\Message;

interface EmbeddedMessageInterface extends BasicMessageInterface
{
}
