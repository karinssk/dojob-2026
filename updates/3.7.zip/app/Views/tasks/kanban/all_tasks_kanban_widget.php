<div class="card">
    <div class="clearfix">
        <div class="bg-white pb0 rounded-top" id="js-kanban-filter-container">
            <div id="kanban-filters"></div>
        </div>

        <div id="load-kanban"></div>

    </div>
</div>

<?php echo view("tasks/batch_update/batch_update_script"); ?>
<?php echo view("tasks/kanban/all_tasks_kanban_helper_js"); ?>
<?php echo view("tasks/quick_filters_helper_js"); ?>