<div class="box">
    <div class="box-content b-r">
        <div class="card-body">
            <h1 class=""><?php echo $project_open; ?></h1>
            <span class="text-off uppercase"><?php echo app_lang("open_projects"); ?></span>
        </div>
    </div>
    <div class="box-content">
        <div class="card-body">
            <h1><?php echo $project_completed; ?></h1>
            <span class="text-off uppercase"><?php echo app_lang("projects_completed"); ?></span>
        </div>
    </div>
</div>