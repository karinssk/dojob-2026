playNotification = function () {
    //play a notification sound
    var notificationSoundVolume = Number("0." + AppHelper.settings.notificationSoundVolume) || 0;
    if (notificationSoundVolume) {
        try {
            //load notification sound
            if ($("body").find("#notificationPlayer").attr("id") !== "notificationPlayer") {
                $("<audio></audio>").attr({
                    'src': AppHelper.notificationSoundSrc,
                    'id': 'notificationPlayer',
                    'type': 'audio/mpeg'
                }).appendTo("body");
            }

            document.getElementById("notificationPlayer").volume = notificationSoundVolume;
            document.getElementById("notificationPlayer").play();
        } catch (err) {
        }
    }
};

showNotificationCountIconOnTopbar = function (count, options) {
    var icon = "bell";
    if (options.isMessageNotification) {
        icon = "mail";
    }
    var content = "<i data-feather='" + icon + "' class='icon'></i>";
    if (count > 0) {
        content += " <span class='badge bg-danger up'>" + count + "</span>";
    }
    $(options.selector).html(content).attr("data-total", count ? count : 0);
    feather.replace();

    //for new message notification, we'll also change the color of the chat icon.
    if (options.isMessageNotification && window.prepareUnreadMessageChatBox && count > 0) {
        window.prepareUnreadMessageChatBox(count);
    }

    IDBHelper.setValue(options.notificationName, count);
};

setNotificationDropdownContent = function (content, options) {
    $(options.selector).parent().find(".dropdown-details").html(content);
};

checkNotifications = function (params, updateStatus) {
    if (params && params.notificationUrl) {
        var data = { check_notification: 1 };
        if (params.isMessageNotification) {
            data = { active_message_id: getCookie("active_chat_id") };
        }

        appAjaxRequest({
            url: params.notificationUrl,
            type: "POST",
            data: data,
            dataType: 'json',
            success: function (result) {
                if (result.success) {
                    if (result.total_notifications && result.total_notifications * 1) {

                        //compaire if there are new notifications, if so, show the notification
                        // if (params.showPushNotification && params.notificationSelector.attr("data-total") != result.total_notifications) {
                        //     playNotification();
                        // }
                        showNotificationCountIconOnTopbar(result.total_notifications, params);

                    }

                    setNotificationDropdownContent(result.notification_list, params);

                    //get notifications list for mobile devices on page load
                    if (!updateStatus && params.notificationUrlForMobile) {
                        appAjaxRequest({
                            url: params.notificationUrlForMobile,
                            type: "POST",
                            data: data,
                            dataType: 'json',
                            success: function (customResultForMobile) {
                                if (customResultForMobile.success) {
                                    setNotificationDropdownContent(customResultForMobile.notification_list, params);
                                }
                            }
                        });
                    }

                    if (updateStatus) {
                        //update last notification checking time
                        appAjaxRequest({
                            url: params.notificationStatusUpdateUrl,
                            success: function () {
                                showNotificationCountIconOnTopbar(0, params);
                            }
                        });
                    }


                }

                if (!updateStatus) {
                    var push_notification = params.pushNotification;
                    if (!push_notification) {
                        push_notification = false;
                    }

                    if (!push_notification) {
                        //if the push notification is enabled, then wait for push notification
                        //if not, the check notification again after sometime
                        var check_notification_after_every = params.checkNotificationAfterEvery;
                        check_notification_after_every = check_notification_after_every * 1000;
                        if (check_notification_after_every < 10000) {
                            check_notification_after_every = 10000; //don't allow to call this requiest before 10 seconds
                        }

                        //overwrite the settings since we added the chat module.
                        //for chat, it should be 5000
                        if (params.isMessageNotification) {
                            check_notification_after_every = 5000;
                        }

                        setTimeout(function () {
                            params.showPushNotification = true;
                            checkNotifications(params);
                        }, check_notification_after_every);
                    }
                }
            }
        });
    }
};

