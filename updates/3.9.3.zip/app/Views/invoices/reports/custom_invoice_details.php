<div class="table-responsive">
    <table id="custom-invoice-details-table" class="display" cellspacing="0" width="100%">
    </table>
</div>
<script type="text/javascript">
    $(document).ready(function() {
        loadInvoiceDetailsTable("#custom-invoice-details-table", "custom");
    });
</script>