ALTER TABLE `clients` ADD COLUMN `managers` text NOT NULL;#

ALTER TABLE `to_do` ADD COLUMN `files` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL, ADD COLUMN `sort` double NOT NULL DEFAULT '1';#

UPDATE `to_do` SET `sort` = `id` WHERE `sort` = 0;#

ALTER TABLE `checklist_items` CHANGE `sort` `sort` double NOT NULL DEFAULT '1';#

UPDATE `checklist_items` SET `sort` = `id` WHERE `sort` = 0;#

ALTER TABLE `tickets` ADD COLUMN `cc_contacts_and_emails` text NULL;#