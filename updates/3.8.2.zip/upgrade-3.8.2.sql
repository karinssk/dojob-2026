ALTER TABLE `events` ADD `related_user_id` INT(11) NOT NULL DEFAULT '0' AFTER `estimate_id`;#

UPDATE `invoices` SET `number_sequence`=`id` WHERE (`number_sequence`<=0 OR ISNULL(`number_sequence`)) AND (`number_year`<=0 OR ISNULL(`number_year`));#