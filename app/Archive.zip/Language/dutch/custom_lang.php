<?php //copy from default_lang.php file and update

$lang["example"] = "Example";

return $lang;