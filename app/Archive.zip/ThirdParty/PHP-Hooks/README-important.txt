#85 php-hooks.php
Changed $accepted_args parameter to 2 to support two parameters on hook filters.
