<?php
namespace App\Controllers;

use Dompdf\Dompdf;
use Dompdf\Options;

class Payslips extends Security_Controller
{
    protected $db;

    public function __construct()
    {
        parent::__construct();
        $this->db = \Config\Database::connect();
    }

    public function index()
    {
        $this->access_only_admin();
        
        try {
            $query = $this->db->query("
                SELECT 
                    p.id,
                    p.salary_period,
                    p.payment_date,
                    p.netpay,
                    CONCAT(u.first_name, ' ', u.last_name) as employee_name
                FROM rise_payslips p
                LEFT JOIN rise_employees e ON e.id = p.employee_id
                LEFT JOIN rise_users u ON u.id = e.user_id
                ORDER BY p.id DESC
            ");
            
            $payslips = $query->getResultArray();
        } catch (\Exception $e) {
            $payslips = [];
            log_message('error', 'Payslips index error: ' . $e->getMessage());
        }

        $view_data['payslips'] = $payslips;
        return $this->template->rander('payslips/index', $view_data);
    }

    public function create()
    {
        $this->access_only_admin();
        
        try {
            $query = $this->db->query("
                SELECT 
                    e.id as emp_id,
                    u.id as user_id,
                    u.first_name,
                    u.last_name,
                    e.name,
                    e.position
                FROM rise_employees e
                LEFT JOIN rise_users u ON u.id = e.user_id
                WHERE u.deleted = 0
                ORDER BY u.first_name, u.last_name
            ");
            
            $employees = $query->getResultArray();
        } catch (\Exception $e) {
            $employees = [];
            log_message('error', 'Payslips create error: ' . $e->getMessage());
        }

        $view_data['employees'] = $employees;
        return $this->template->rander('payslips/create', $view_data);
    }

    public function store()
    {
        $this->access_only_admin();
        
        $validation = \Config\Services::validation();
        
        $validation->setRules([
            'employee_id' => 'required|numeric',
            'salary_period' => 'required',
            'payment_date' => 'required|valid_date',
            'year' => 'required|numeric',
            'netpay' => 'required|decimal'
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }

        $this->db->transStart();

        try {
            // Get form data
            $employee_id = $this->request->getPost('employee_id');
            $salary_period = $this->request->getPost('salary_period');
            $payment_date = $this->request->getPost('payment_date');
            $year = $this->request->getPost('year');
            $netpay = $this->request->getPost('netpay');
            $employee_signature = $this->request->getPost('employee_signature') ?? '';

            // Get employee info
            $employee_query = $this->db->query("SELECT user_id FROM rise_employees WHERE id = ?", [$employee_id]);
            $employee = $employee_query->getRowArray();
            
            if (!$employee) {
                throw new \Exception('Employee not found');
            }

            // Insert payslip
            $payslip_data = [
                'user_id' => $employee['user_id'],
                'employee_id' => $employee_id,
                'salary_period' => $salary_period,
                'payment_date' => $payment_date,
                'year' => $year,
                'netpay' => $netpay,
                'employee_signature' => $employee_signature,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ];

            $this->db->table('rise_payslips')->insert($payslip_data);
            $payslip_id = $this->db->insertID();

            if (!$payslip_id) {
                throw new \Exception('Failed to create payslip');
            }

            // Insert earnings
            $salary = floatval($this->request->getPost('salary') ?? 0);
            $overtime = floatval($this->request->getPost('overtime') ?? 0);
            $commission = floatval($this->request->getPost('commission') ?? 0);
            $allowance = floatval($this->request->getPost('allowance') ?? 0);
            $bonus = floatval($this->request->getPost('bonus') ?? 0);
            $earning_other = floatval($this->request->getPost('earning_other') ?? 0);
            $total_earning = $salary + $overtime + $commission + $allowance + $bonus + $earning_other;

            $earnings_data = [
                'payslip_id' => $payslip_id,
                'salary' => $salary,
                'overtime' => $overtime,
                'commission' => $commission,
                'allowance' => $allowance,
                'bonus' => $bonus,
                'earning_other' => $earning_other,
                'total_earning' => $total_earning,
                'ytd_earning' => $total_earning
            ];

            $this->db->table('rise_earnings')->insert($earnings_data);

            // Insert deductions
            $tax = floatval($this->request->getPost('tax') ?? 0);
            $social_security = floatval($this->request->getPost('social_security') ?? 0);
            $deduction_other = floatval($this->request->getPost('deduction_other') ?? 0);
            $total_deduction = $tax + $social_security + $deduction_other;

            $deductions_data = [
                'payslip_id' => $payslip_id,
                'tax' => $tax,
                'social_security' => $social_security,
                'deduction_other' => $deduction_other,
                'total_deduction' => $total_deduction
            ];

            $this->db->table('rise_deductions')->insert($deductions_data);

            $this->db->transComplete();

            if ($this->db->transStatus() === FALSE) {
                throw new \Exception('Transaction failed');
            }

            return redirect()->to(base_url('payslips'))->with('success', 'Payslip created successfully!');

        } catch (\Exception $e) {
            $this->db->transRollback();
            log_message('error', 'Payslip store error: ' . $e->getMessage());
            return redirect()->back()->withInput()->with('error', 'Failed to create payslip: ' . $e->getMessage());
        }
    }

    public function view($id)
    {
        $this->access_only_admin();
        
        try {
            // Get payslip with employee info
            $payslip_query = $this->db->query("
                SELECT 
                    p.*,
                    CONCAT(u.first_name, ' ', u.last_name) as employee_name,
                    e.position,
                    e.company_name
                FROM rise_payslips p
                LEFT JOIN rise_employees e ON e.id = p.employee_id
                LEFT JOIN rise_users u ON u.id = e.user_id
                WHERE p.id = ?
            ", [$id]);
            
            $payslip = $payslip_query->getRowArray();
            
            if (!$payslip) {
                return redirect()->to(base_url('payslips'))->with('error', 'Payslip not found');
            }

            // Get earnings
            $earnings_query = $this->db->query("SELECT * FROM rise_earnings WHERE payslip_id = ?", [$id]);
            $earnings = $earnings_query->getRowArray();

            // Get deductions
            $deductions_query = $this->db->query("SELECT * FROM rise_deductions WHERE payslip_id = ?", [$id]);
            $deductions = $deductions_query->getRowArray();

            $view_data = [
                'payslip' => $payslip,
                'earnings' => $earnings,
                'deductions' => $deductions
            ];

            return $this->template->rander('payslips/view', $view_data);

        } catch (\Exception $e) {
            log_message('error', 'Payslip view error: ' . $e->getMessage());
            return redirect()->to(base_url('payslips'))->with('error', 'Error loading payslip');
        }
    }

    public function print($id)
    {
        $this->access_only_admin();
        
        try {
            // Get payslip with employee info
            $payslip_query = $this->db->query("
                SELECT 
                    p.*,
                    CONCAT(u.first_name, ' ', u.last_name) as employee_name,
                    e.position,
                    e.company_name
                FROM rise_payslips p
                LEFT JOIN rise_employees e ON e.id = p.employee_id
                LEFT JOIN rise_users u ON u.id = e.user_id
                WHERE p.id = ?
            ", [$id]);
            
            $payslip = $payslip_query->getRowArray();
            
            if (!$payslip) {
                show_404();
            }

            // Get earnings
            $earnings_query = $this->db->query("SELECT * FROM rise_earnings WHERE payslip_id = ?", [$id]);
            $earnings = $earnings_query->getRowArray();
            
            if (!$earnings) {
                $earnings = [
                    'salary' => 0, 'overtime' => 0, 'commission' => 0,
                    'allowance' => 0, 'bonus' => 0, 'earning_other' => 0,
                    'total_earning' => 0, 'ytd_earning' => 0
                ];
            }

            // Get deductions
            $deductions_query = $this->db->query("SELECT * FROM rise_deductions WHERE payslip_id = ?", [$id]);
            $deductions = $deductions_query->getRowArray();
            
            if (!$deductions) {
                $deductions = [
                    'tax' => 0, 'social_security' => 0, 'deduction_other' => 0,
                    'total_deduction' => 0
                ];
            }

            return view('payslips/print', [
                'payslip' => $payslip,
                'earnings' => $earnings,
                'deductions' => $deductions
            ]);

        } catch (\Exception $e) {
            log_message('error', 'Payslip print error: ' . $e->getMessage());
            show_404();
        }
    }

    public function delete($id)
    {
        $this->access_only_admin();
        
        $this->db->transStart();

        try {
            // Delete in correct order due to foreign keys
            $this->db->query("DELETE FROM rise_deductions WHERE payslip_id = ?", [$id]);
            $this->db->query("DELETE FROM rise_earnings WHERE payslip_id = ?", [$id]);
            $this->db->query("DELETE FROM rise_payslips WHERE id = ?", [$id]);

            $this->db->transComplete();

            if ($this->db->transStatus() === FALSE) {
                throw new \Exception('Transaction failed');
            }

            return redirect()->to(base_url('payslips'))->with('success', 'Payslip deleted successfully!');

        } catch (\Exception $e) {
            $this->db->transRollback();
            log_message('error', 'Payslip delete error: ' . $e->getMessage());
            return redirect()->to(base_url('payslips'))->with('error', 'Failed to delete payslip');
        }
    }

    public function downloadPdf($id)
    {
        $this->access_only_admin();
        
        try {
            // Get payslip data (reuse print logic)
            $payslip_query = $this->db->query("
                SELECT 
                    p.*,
                    CONCAT(u.first_name, ' ', u.last_name) as employee_name,
                    e.position,
                    e.company_name
                FROM rise_payslips p
                LEFT JOIN rise_employees e ON e.id = p.employee_id
                LEFT JOIN rise_users u ON u.id = e.user_id
                WHERE p.id = ?
            ", [$id]);
            
            $payslip = $payslip_query->getRowArray();
            
            if (!$payslip) {
                show_404();
            }

            $earnings_query = $this->db->query("SELECT * FROM rise_earnings WHERE payslip_id = ?", [$id]);
            $earnings = $earnings_query->getRowArray() ?? [];

            $deductions_query = $this->db->query("SELECT * FROM rise_deductions WHERE payslip_id = ?", [$id]);
            $deductions = $deductions_query->getRowArray() ?? [];

            $data = [
                'payslip' => $payslip,
                'earnings' => $earnings,
                'deductions' => $deductions
            ];

            // Generate PDF
            $html = view('payslips/print', $data);

            $options = new Options();
            $options->set('defaultFont', 'DejaVu Sans');
            $options->set('isRemoteEnabled', true);
            
            $dompdf = new Dompdf($options);
            $dompdf->loadHtml($html);
            $dompdf->setPaper('A4', 'portrait');
            $dompdf->render();

            $dompdf->stream("payslip_{$id}.pdf", ["Attachment" => false]);

        } catch (\Exception $e) {
            log_message('error', 'PDF generation error: ' . $e->getMessage());
            show_404();
        }
    }

    // Debug method - remove in production
    public function test_db()
    {
        $this->access_only_admin();
        
        echo "<h2>Database Test Results</h2>";
        
        $tables = ['rise_users', 'rise_employees', 'rise_payslips', 'rise_earnings', 'rise_deductions'];
        
        foreach ($tables as $table) {
            try {
                $query = $this->db->query("SHOW TABLES LIKE '$table'");
                if ($query->getNumRows() > 0) {
                    $count = $this->db->table($table)->countAllResults();
                    echo "<p>✅ Table '$table' exists with $count records</p>";
                } else {
                    echo "<p>❌ Table '$table' does not exist</p>";
                }
            } catch (\Exception $e) {
                echo "<p>❌ Error checking table '$table': " . $e->getMessage() . "</p>";
            }
        }
        
        // Show sample data
        try {
            $users = $this->db->query("SELECT id, first_name, last_name FROM rise_users LIMIT 3")->getResultArray();
            echo "<h3>Sample Users:</h3><pre>" . print_r($users, true) . "</pre>";
            
            $employees = $this->db->query("SELECT * FROM rise_employees LIMIT 3")->getResultArray();
            echo "<h3>Sample Employees:</h3><pre>" . print_r($employees, true) . "</pre>";
        } catch (\Exception $e) {
            echo "<p>Error fetching sample data: " . $e->getMessage() . "</p>";
        }
    }
}