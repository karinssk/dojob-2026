/**
 * Enhanced Kanban Board with Dynamic Status Management
 */

class EnhancedKanbanBoard {
    constructor(projectId) {
        this.projectId = projectId;
        this.boardData = {};
        this.statuses = [];
        this.init();
    }

    init() {
        this.loadStatuses();
        this.setupEventListeners();
    }

    async loadStatuses() {
        try {
            console.log("🔄 Loading statuses...");
            console.log("📍 Base URL: https://api-dojob.rubyshop.co.th/api/", window.baseUrl);
            console.log("📍 Project ID:", this.projectId);
            
            const url = `${window.baseUrl}task_status/get_statuses`;
            console.log("📍 Full URL:", url);
            
            const response = await fetch(`https://api-dojob.rubyshop.co.th/api/task_status/get_statuses`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: `project_id=${this.projectId}`
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();
            
            if (result && result.success) {
                this.statuses = result.data;
                console.log("✅ Statuses loaded:", this.statuses);
                this.loadTasks();
            } else {
                console.error("❌ Failed to load statuses:", result ? result.error : 'No response received');
                this.showError(result ? result.error : 'Failed to load status configuration');
            }
        } catch (error) {
            console.error("❌ Network error loading statuses:", error);
            console.log("🔄 Falling back to default statuses...");
            
            // Fallback to default statuses if StatusManager is not available
            this.statuses = [
                { id: 1, title: 'To Do', key_name: 'to_do', color: '#F9A52D', sort: 0, hide_from_kanban: 0 },
                { id: 2, title: 'In Progress', key_name: 'in_progress', color: '#1672B9', sort: 1, hide_from_kanban: 0 },
                { id: 3, title: 'Done', key_name: 'done', color: '#00B393', sort: 2, hide_from_kanban: 0 }
            ];
            
            console.log("✅ Using fallback statuses:", this.statuses);
            this.loadTasks();
        }
    }

    async loadTasks() {
        try {
            console.log("🔄 Loading tasks from Node.js API...");

            const response = await fetch(
                `https://api-dojob.rubyshop.co.th/api/kanban/${this.projectId}`,
                {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    credentials: "include",
                }
            );

            const result = await response.json();

            if (result.success) {
                console.log("✅ API data received:", result.data);
                this.boardData = result.data;
                this.renderBoard();
            } else {
                console.error("❌ API Error:", result.error);
                this.showError(result.error);
            }
        } catch (error) {
            console.error("❌ Network error:", error);
            this.showError("Failed to load tasks - make sure Node.js API is running on port 3001");
        }
    }

    renderBoard() {
        const boardContainer = document.getElementById("kanban-board-container");
        if (!boardContainer) {
            console.error("❌ Board container not found");
            return;
        }

        console.log("🎨 Rendering enhanced board...");

        // Create columns based on statuses using Tailwind design
        const columnsHtml = this.statuses.map(status => {
            const tasks = this.getTasksForStatus(status.key_name);
            return this.renderColumn(status, tasks);
        }).join('');

        // Add column button
        const addColumnButton = `
            <div class="w-10 h-10 bg-white rounded-md flex items-center justify-center text-blue-600 font-bold text-lg cursor-pointer mt-8 hover:bg-gray-50 transition-colors">
                +
            </div>
        `;

        boardContainer.innerHTML = `
            <div class="flex gap-4 overflow-x-auto" id="kanban-columns-container">
                ${columnsHtml}
                ${addColumnButton}
            </div>
        `;

        this.setupDragAndDrop();
        this.setupColumnReordering();
    }

    renderBoardHeader() {
        return `
            <div class="board-header">
                <div class="board-controls">
                    <h3 class="board-title">Project Board</h3>
                    <div class="board-actions">
                        <button id="add-status-btn" class="btn btn-outline-primary btn-sm">
                            <i class="fas fa-plus"></i> Add Status
                        </button>
                        <button id="manage-statuses-btn" class="btn btn-outline-secondary btn-sm">
                            <i class="fas fa-cog"></i> Manage Statuses
                        </button>
                        <button id="refresh-board-btn" class="btn btn-outline-info btn-sm">
                            <i class="fas fa-sync-alt"></i> Refresh
                        </button>
                    </div>
                </div>
            </div>
        `;
    }

    renderColumn(status, tasks) {
        return `
            <div class="w-64 bg-white rounded-md p-3 flex-shrink-0 kanban-column" data-status="${status.key_name}" data-status-id="${status.id}">
                <div class="font-semibold text-gray-700 flex justify-between items-center mb-2">
                    <span>${status.title.toUpperCase()}</span>
                    <span class="text-xs bg-gray-200 text-gray-700 px-1 rounded task-count">${tasks.length}</span>
                </div>
                <div class="tasks-container" data-status="${status.key_name}" data-status-id="${status.id}">
                    ${this.renderTasks(tasks, status.key_name)}
                </div>
                <button class="text-blue-600 text-sm hover:underline add-task-btn" data-status="${status.key_name}">
                    ＋ Create
                </button>
            </div>
        `;
    }

    getTasksForStatus(statusKey) {
        if (!this.boardData || !Array.isArray(this.boardData)) {
            return [];
        }

        const column = this.boardData.find(col => col.key_name === statusKey);
        return column ? (column.tasks || []) : [];
    }

    renderTasks(tasks, status) {
        if (tasks.length === 0) {
            return this.renderCreateOnlyCard(status);
        }

        return tasks.map((task, index) => {
            const isLastTask = index === tasks.length - 1;
            return this.renderTaskCard(task, isLastTask, status);
        }).join('');
    }

    renderTaskCard(task, isLastTask = false, status = null) {
        const hasImages = task.images && task.images.length > 0;
        const imagePreview = hasImages ? this.renderImagePreview(task.images) : "";

        const assignee = task.assigned_to ? {
            name: `${task.first_name || ""} ${task.last_name || ""}`.trim() || "Unassigned",
            avatar: task.user_image ? this.parseUserImage(task.user_image) : null,
            initials: this.getInitials(`${task.first_name || ""} ${task.last_name || ""}`)
        } : null;

        const assigneeAvatar = assignee ? this.renderAssigneeAvatar(assignee) : "";
        const priority = this.mapPriority(task.priority_id);
        const priorityIndicator = this.renderPriorityIndicator(priority, task.priority_color);

        let cleanTaskId = parseInt(task.id, 10);
        if (!cleanTaskId || cleanTaskId < 1) {
            console.error("Invalid task ID:", task.id);
            cleanTaskId = 0;
        }

        const taskStatus = status || this.getTaskStatus(task);
     
        return `
            <div class="bg-white rounded-md border border-gray-200 p-3 mb-3 task-card shadow-sm hover:shadow-md transition-shadow ${isLastTask ? "last-task" : ""}" data-task-id="${cleanTaskId}" draggable="true">
                ${imagePreview ? `<div class="h-20 bg-gray-100 rounded mb-2 flex items-center justify-center text-xs text-gray-400 overflow-hidden">${imagePreview}</div>` : ""}
                
                <div class="text-gray-800 mb-2 font-medium">${this.escapeHtml(task.title)}</div>
                
                ${task.deadline ? `<div class="text-xs text-red-500 font-medium mb-2 flex items-center gap-1"><span class="text-red-400">⚠</span> ${this.formatDate(task.deadline)}</div>` : ""}
                
                <div class="flex justify-between items-center text-xs">
                    <div class="flex items-center gap-1 text-blue-600">
                        <input type="checkbox" class="w-3 h-3 accent-blue-600">
                        <span class="font-medium">TETS-${task.id}</span>
                    </div>
                    <div class="flex items-center gap-2">
                        ${task.description ? `<span class="text-gray-400">📋 0/5</span>` : ""}
                        <span class="text-gray-400 cursor-pointer hover:text-gray-600" title="More options">⌃</span>
                    </div>
                </div>
                
                ${isLastTask ? this.renderCreateSection(taskStatus) : ""}
            </div>
        `;
    }

    renderCreateOnlyCard(status = "to_do") {
        return `
            <div class="task-card create-only-card" data-create-only="true">
                ${this.renderCreateSection(status)}
            </div>
        `;
    }

    renderCreateSection(status) {
        return `
            <div class="task-create-section">
                <button class="create-task-button" data-status="${status}">
                    <i class="fas fa-plus"></i>
                    Create
                </button>
            </div>
        `;
    }

    setupColumnReordering() {
        const columnsContainer = document.getElementById('kanban-columns-container');
        if (!columnsContainer) return;

        // Make columns sortable
        new Sortable(columnsContainer, {
            animation: 150,
            ghostClass: 'column-ghost',
            chosenClass: 'column-chosen',
            dragClass: 'column-drag',
            handle: '.column-header',
            onEnd: (evt) => {
                this.handleColumnReorder(evt);
            }
        });
    }

    async handleColumnReorder(evt) {
        console.log("🔄 Column reordered:", evt);
        
        const columns = Array.from(document.querySelectorAll('.kanban-column'));
        const statusOrders = columns.map((column, index) => ({
            id: parseInt(column.dataset.statusId),
            sort: index
        }));

        try {
            const response = await fetch(`${window.baseUrl}task_status/reorder_statuses`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: `status_orders=${encodeURIComponent(JSON.stringify(statusOrders))}`
            });

            const result = await response.json();
            
            if (result.success) {
                console.log("✅ Columns reordered successfully");
                this.showSuccess(result.message);
                // Reload to reflect new order
                setTimeout(() => this.loadStatuses(), 500);
            } else {
                console.error("❌ Failed to reorder columns:", result.error);
                this.showError(result.error);
                // Revert visual change
                this.renderBoard();
            }
        } catch (error) {
            console.error("❌ Network error:", error);
            this.showError("Failed to save column order");
            this.renderBoard();
        }
    }

    setupEventListeners() {
        // Add status button
        document.addEventListener('click', (e) => {
            if (e.target.closest('#add-status-btn')) {
                this.showAddStatusModal();
            }
        });

        // Manage statuses button
        document.addEventListener('click', (e) => {
            if (e.target.closest('#manage-statuses-btn')) {
                this.showManageStatusesModal();
            }
        });

        // Column menu buttons
        document.addEventListener('click', (e) => {
            if (e.target.closest('.column-menu-btn')) {
                const statusId = e.target.closest('.column-menu-btn').dataset.statusId;
                this.showColumnMenu(e.target, statusId);
            }
        });

        // Refresh button
        document.addEventListener('click', (e) => {
            if (e.target.closest('#refresh-board-btn')) {
                this.loadStatuses();
            }
        });

        // Add task buttons
        document.addEventListener('click', (e) => {
            if (e.target.closest('.add-task-btn')) {
                const status = e.target.closest('.add-task-btn').dataset.status;
                this.openCreateTaskModal(status);
            }
        });

        // Create task buttons
        document.addEventListener('click', (e) => {
            if (e.target.closest('.create-task-button')) {
                const button = e.target.closest('.create-task-button');
                const status = button.dataset.status;
                this.showInlineTaskForm(button, status);
            }
        });

        // Task reorder buttons
        document.addEventListener('click', (e) => {
            if (e.target.closest('.reorder-btn')) {
                e.preventDefault();
                e.stopPropagation();
                const button = e.target.closest('.reorder-btn');
                const taskId = button.dataset.taskId;
                const direction = button.dataset.direction;
                this.reorderTask(taskId, direction);
            }
        });

        // Handle form submissions
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('btn-create-task')) {
                e.preventDefault();
                this.handleCreateTask(e.target);
            } else if (e.target.classList.contains('btn-cancel-task')) {
                e.preventDefault();
                this.hideInlineTaskForm(e.target);
            }
        });

        // Handle Enter/Escape in task input
        document.addEventListener('keydown', (e) => {
            if (e.target.classList.contains('task-title-input')) {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    const createBtn = e.target.closest('.inline-task-form').querySelector('.btn-create-task');
                    if (createBtn) createBtn.click();
                } else if (e.key === 'Escape') {
                    e.preventDefault();
                    const cancelBtn = e.target.closest('.inline-task-form').querySelector('.btn-cancel-task');
                    if (cancelBtn) cancelBtn.click();
                }
            }
        });
    }

    showAddStatusModal() {
        const modalHtml = `
            <div class="modal fade" id="addStatusModal" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Add New Status</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <form id="addStatusForm">
                                <div class="mb-3">
                                    <label for="statusTitle" class="form-label">Status Title</label>
                                    <input type="text" class="form-control" id="statusTitle" required>
                                </div>
                                <div class="mb-3">
                                    <label for="statusColor" class="form-label">Color</label>
                                    <input type="color" class="form-control form-control-color" id="statusColor" value="#6c757d">
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary" id="saveStatusBtn">Add Status</button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Remove existing modal
        const existingModal = document.getElementById('addStatusModal');
        if (existingModal) existingModal.remove();

        // Add modal to page
        document.body.insertAdjacentHTML('beforeend', modalHtml);

        // Show modal
        const modal = new bootstrap.Modal(document.getElementById('addStatusModal'));
        modal.show();

        // Handle save
        document.getElementById('saveStatusBtn').addEventListener('click', () => {
            this.handleAddStatus(modal);
        });
    }

    async handleAddStatus(modal) {
        const title = document.getElementById('statusTitle').value.trim();
        const color = document.getElementById('statusColor').value;

        if (!title) {
            this.showError('Status title is required');
            return;
        }

        try {
            const response = await fetch(`${window.baseUrl}task_status/add_status`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: `title=${encodeURIComponent(title)}&color=${encodeURIComponent(color)}&project_id=${this.projectId}`
            });

            const result = await response.json();
            
            if (result.success) {
                this.showSuccess(result.message);
                modal.hide();
                // Reload board with new status
                setTimeout(() => this.loadStatuses(), 500);
            } else {
                this.showError(result.error);
            }
        } catch (error) {
            console.error("❌ Network error:", error);
            this.showError("Failed to add status");
        }
    }

    showColumnMenu(button, statusId) {
        // Remove existing menus
        document.querySelectorAll('.column-context-menu').forEach(menu => menu.remove());

        const status = this.statuses.find(s => s.id == statusId);
        if (!status) return;

        const menuHtml = `
            <div class="column-context-menu" style="position: absolute; z-index: 1000; background: white; border: 1px solid #ddd; border-radius: 4px; box-shadow: 0 2px 8px rgba(0,0,0,0.15); min-width: 150px;">
                <div class="menu-item" data-action="edit" data-status-id="${statusId}">
                    <i class="fas fa-edit"></i> Edit Status
                </div>
                <div class="menu-item" data-action="toggle-visibility" data-status-id="${statusId}">
                    <i class="fas fa-eye${status.hide_from_kanban ? '' : '-slash'}"></i> 
                    ${status.hide_from_kanban ? 'Show' : 'Hide'} in Kanban
                </div>
                <div class="menu-divider"></div>
                <div class="menu-item text-danger" data-action="delete" data-status-id="${statusId}">
                    <i class="fas fa-trash"></i> Delete Status
                </div>
            </div>
        `;

        document.body.insertAdjacentHTML('beforeend', menuHtml);
        
        const menu = document.querySelector('.column-context-menu');
        const rect = button.getBoundingClientRect();
        
        menu.style.left = `${rect.left}px`;
        menu.style.top = `${rect.bottom + 5}px`;

        // Handle menu clicks
        menu.addEventListener('click', (e) => {
            const action = e.target.closest('.menu-item')?.dataset.action;
            const statusId = e.target.closest('.menu-item')?.dataset.statusId;
            
            if (action && statusId) {
                this.handleColumnMenuAction(action, statusId);
            }
            
            menu.remove();
        });

        // Close menu on outside click
        setTimeout(() => {
            document.addEventListener('click', function closeMenu(e) {
                if (!menu.contains(e.target)) {
                    menu.remove();
                    document.removeEventListener('click', closeMenu);
                }
            });
        }, 100);
    }

    async handleColumnMenuAction(action, statusId) {
        switch (action) {
            case 'edit':
                this.showEditStatusModal(statusId);
                break;
            case 'toggle-visibility':
                await this.toggleStatusVisibility(statusId);
                break;
            case 'delete':
                await this.deleteStatus(statusId);
                break;
        }
    }

    async toggleStatusVisibility(statusId) {
        const status = this.statuses.find(s => s.id == statusId);
        if (!status) return;

        const newVisibility = status.hide_from_kanban ? 0 : 1;

        try {
            const response = await fetch(`${window.baseUrl}task_status/toggle_kanban_visibility`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: `status_id=${statusId}&hide_from_kanban=${newVisibility}`
            });

            const result = await response.json();
            
            if (result.success) {
                this.showSuccess(result.message);
                setTimeout(() => this.loadStatuses(), 500);
            } else {
                this.showError(result.error);
            }
        } catch (error) {
            console.error("❌ Network error:", error);
            this.showError("Failed to update status visibility");
        }
    }

    async deleteStatus(statusId) {
        const status = this.statuses.find(s => s.id == statusId);
        if (!status) return;

        if (!confirm(`Are you sure you want to delete the "${status.title}" status? This action cannot be undone.`)) {
            return;
        }

        try {
            const response = await fetch(`${window.baseUrl}task_status/delete_status`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: `status_id=${statusId}`
            });

            const result = await response.json();
            
            if (result.success) {
                this.showSuccess(result.message);
                setTimeout(() => this.loadStatuses(), 500);
            } else {
                this.showError(result.error);
            }
        } catch (error) {
            console.error("❌ Network error:", error);
            this.showError("Failed to delete status");
        }
    }

    // Inherit other methods from original KanbanBoard
    setupDragAndDrop() {
        // Implementation from original kanban-board.js
        const taskCards = document.querySelectorAll(".task-card");
        const containers = document.querySelectorAll(".tasks-container");

        taskCards.forEach((card) => {
            if (card.dataset.createOnly === "true") return;

            card.addEventListener("dragstart", (e) => {
                e.dataTransfer.setData("text/plain", card.dataset.taskId);
                card.classList.add("dragging");
            });

            card.addEventListener("dragend", () => {
                card.classList.remove("dragging");
            });

            card.addEventListener("click", (e) => {
                if (e.target.closest(".create-task-button") ||
                    e.target.closest(".task-create-section") ||
                    e.target.closest(".inline-task-form") ||
                    e.target.closest(".reorder-btn") ||
                    e.target.closest(".dragging")) {
                    return;
                }

                if (card.dataset.taskId && card.dataset.taskId !== "undefined") {
                    this.openTaskModal(card.dataset.taskId);
                }
            });
        });

        containers.forEach((container) => {
            container.addEventListener("dragover", (e) => {
                e.preventDefault();
                container.classList.add("drag-over");
            });

            container.addEventListener("dragleave", (e) => {
                if (!container.contains(e.relatedTarget)) {
                    container.classList.remove("drag-over");
                }
            });

            container.addEventListener("drop", (e) => {
                e.preventDefault();
                container.classList.remove("drag-over");

                const taskId = e.dataTransfer.getData("text/plain");
                const newStatusKey = container.dataset.status;
                
                // Find status ID from key
                const status = this.statuses.find(s => s.key_name === newStatusKey);
                if (status) {
                    this.updateTaskStatus(taskId, status.id);
                }
            });
        });
    }

    async updateTaskStatus(taskId, statusId) {
        console.log(`🎯 Updating Task ${taskId} → Status ID ${statusId}`);

        try {
            const response = await fetch(`https://api-dojob.rubyshop.co.th/api/task/${taskId}/status`, {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                },
                credentials: "include",
                body: JSON.stringify({
                    status_id: statusId,
                }),
            });

            const result = await response.json();

            if (result.success) {
                console.log("✅ Status updated successfully");
                const status = this.statuses.find(s => s.id == statusId);
                this.showSuccess(`Task moved to ${status ? status.title : 'new status'}`);
                setTimeout(() => this.loadTasks(), 500);
            } else {
                console.error("❌ Update failed:", result.error);
                this.showError(result.error || "Failed to update status");
                this.loadTasks();
            }
        } catch (error) {
            console.error("❌ Network error:", error);
            this.showError("Connection error - make sure Node.js API is running");
            this.loadTasks();
        }
    }

    // Utility methods
    mapPriority(priorityId) {
        // Use dynamic priority mapping from database instead of hardcoded values
        if (window.priorityMapping && window.priorityMapping[priorityId]) {
            return window.priorityMapping[priorityId].text.toLowerCase();
        }
        
        // Fallback mapping if database data not available
        const fallbackMap = { 0: "lowest", 1: "low", 2: "medium", 3: "high", 4: "highest" };
        return fallbackMap[priorityId] || "medium";
    }

    parseUserImage(imageData) {
        if (!imageData) return null;
        try {
            if (typeof imageData === "string" && imageData.includes("file_name")) {
                const match = imageData.match(/s:\d+:"([^"]+)"/);
                if (match) {
                    return `${window.baseUrl}files/profile_images/${match[1]}`;
                }
            }
            return imageData;
        } catch (e) {
            return null;
        }
    }

    getInitials(name) {
        if (!name || name === "Unassigned") return "U";
        return name.split(" ").map((n) => n[0]).join("").toUpperCase().substring(0, 2);
    }

    escapeHtml(text) {
        const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
        return text.replace(/[&<>"']/g, (m) => map[m]);
    }

    formatDate(dateString) {
        return new Date(dateString).toLocaleDateString();
    }

    showSuccess(message) {
        console.log("✅ Success:", message);
        
        // Create a simple toast notification
        const toast = document.createElement('div');
        toast.className = 'toast-notification toast-success';
        toast.innerHTML = `<i class="fas fa-check-circle"></i> ${message}`;
        toast.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #d4edda;
            color: #155724;
            padding: 12px 20px;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            z-index: 10000;
            font-size: 14px;
            max-width: 300px;
        `;
        
        document.body.appendChild(toast);
        
        // Remove after 3 seconds
        setTimeout(() => {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 3000);
    }

    showError(message) {
        console.error("❌ Error:", message);
        
        // Create a simple toast notification
        const toast = document.createElement('div');
        toast.className = 'toast-notification toast-error';
        toast.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${message}`;
        toast.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #f8d7da;
            color: #721c24;
            padding: 12px 20px;
            border: 1px solid #f5c6cb;
            border-radius: 4px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            z-index: 10000;
            font-size: 14px;
            max-width: 300px;
        `;
        
        document.body.appendChild(toast);
        
        // Remove after 5 seconds (longer for errors)
        setTimeout(() => {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 5000);
    }

    // Additional methods from original implementation
    renderImagePreview(images) {
        if (!images || images.length === 0) return "Screenshot";

        const getImageUrl = (image) => {
            if (typeof image === "string") {
                return image;
            } else if (typeof image === "object" && image !== null) {
                if (image.url) return image.url;
                else if (image.filename) return `https://dojob.rubyshop.co.th/files/timeline_files/${image.filename}`;
                else if (image.file_name) return `https://dojob.rubyshop.co.th/files/timeline_files/${image.file_name}`;
            }
            return null;
        };

        if (images.length === 1) {
            const imageUrl = getImageUrl(images[0]);
            if (!imageUrl) return "Screenshot";
            return `<img src="${imageUrl}" alt="Task image" class="w-full h-full object-cover rounded" loading="lazy">`;
        } else {
            const firstImageUrl = getImageUrl(images[0]);
            if (!firstImageUrl) return "Screenshot";
            const remainingCount = images.length - 1;
            return `<div class="relative w-full h-full"><img src="${firstImageUrl}" alt="Task image" class="w-full h-full object-cover rounded" loading="lazy"><div class="absolute top-1 right-1 bg-black bg-opacity-70 text-white text-xs px-1 rounded">+${remainingCount}</div></div>`;
        }
    }

    renderAssigneeAvatar(assignee) {
        if (assignee.avatar && assignee.avatar !== "") {
            return `<div class="assignee-avatar" title="${this.escapeHtml(assignee.name)}"><img src="${assignee.avatar}" alt="${this.escapeHtml(assignee.name)}" class="avatar-img"></div>`;
        } else {
            return `<div class="assignee-avatar initials" title="${this.escapeHtml(assignee.name)}"><span class="avatar-initials">${assignee.initials}</span></div>`;
        }
    }

    renderPriorityIndicator(priority, color) {
        const priorityIcons = {
            high: "fas fa-arrow-up",
            medium: "fas fa-minus", 
            low: "fas fa-arrow-down",
            normal: "fas fa-minus",
        };
        const icon = priorityIcons[priority] || priorityIcons["normal"];
        return `<span class="priority-indicator priority-${priority}" style="color: ${color}" title="${priority.charAt(0).toUpperCase() + priority.slice(1)} Priority"><i class="${icon}"></i></span>`;
    }

    getTaskStatus(task) {
        if (task.status_id) {
            const statusMap = { 1: "to_do", 2: "in_progress", 3: "done" };
            return statusMap[task.status_id] || "to_do";
        }
        return "to_do";
    }

    openTaskModal(taskId) {
        if (window.taskModal) {
            window.taskModal.openTask(taskId);
        } else {
            console.error("Task modal not available - loading it now...");
            if (typeof TaskModal !== "undefined") {
                window.taskModal = new TaskModal();
                window.taskModal.openTask(taskId);
            } else {
                alert(`Task modal not loaded. Task ID: ${taskId}`);
            }
        }
    }

    openCreateTaskModal(status) {
        if (window.showCreateTaskModal) {
            window.showCreateTaskModal(this.projectId, status);
        } else {
            console.log("Create task modal not available");
        }
    }

    showInlineTaskForm(button, status) {
        this.hideAllInlineForms();
        const formHtml = `
            <div class="inline-task-form" data-status="${status}">
                <textarea class="task-title-input" placeholder="What needs to be done?" rows="2" autofocus></textarea>
                <div class="form-actions">
                    <button class="btn-create-task btn-primary">Create</button>
                    <button class="btn-cancel-task btn-secondary">Cancel</button>
                    <div class="form-controls">
                        <button type="button" title="Add description"><i class="fas fa-align-left"></i></button>
                        <button type="button" title="Set due date"><i class="fas fa-calendar"></i></button>
                        <button type="button" title="Assign"><i class="fas fa-user"></i></button>
                        <button type="button" title="Add attachment"><i class="fas fa-paperclip"></i></button>
                    </div>
                </div>
            </div>
        `;
        button.insertAdjacentHTML("afterend", formHtml);
        const textarea = button.nextElementSibling.querySelector(".task-title-input");
        if (textarea) textarea.focus();
    }

    hideInlineTaskForm(element) {
        const form = element.closest(".inline-task-form");
        if (form) form.remove();
    }

    hideAllInlineForms() {
        document.querySelectorAll(".inline-task-form").forEach((form) => form.remove());
    }

    async handleCreateTask(button) {
        const form = button.closest('.inline-task-form');
        const textarea = form.querySelector('.task-title-input');
        const title = textarea.value.trim();
        const status = form.dataset.status;

        if (!title) {
            this.showError('Task title is required');
            return;
        }

        try {
            // Find status ID from key
            const statusObj = this.statuses.find(s => s.key_name === status);
            if (!statusObj) {
                this.showError('Invalid status');
                return;
            }

            const response = await fetch('https://api-dojob.rubyshop.co.th/api/tasks', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                credentials: 'include',
                body: JSON.stringify({
                    title: title,
                    project_id: this.projectId,
                    status_id: statusObj.id
                })
            });

            const result = await response.json();

            if (result.success) {
                this.showSuccess('Task created successfully');
                form.remove();
                setTimeout(() => this.loadTasks(), 500);
            } else {
                this.showError(result.error || 'Failed to create task');
            }
        } catch (error) {
            console.error('❌ Network error:', error);
            this.showError('Connection error - make sure Node.js API is running');
        }
    }

    async reorderTask(taskId, direction) {
        console.log(`🔄 Reordering Task ${taskId} ${direction}`);
        try {
            const response = await fetch(`https://api-dojob.rubyshop.co.th/api/task/${taskId}/reorder`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                credentials: "include",
                body: JSON.stringify({ direction: direction, project_id: this.projectId }),
            });

            const result = await response.json();
            if (result.success) {
                console.log("✅ Task reordered successfully");
                this.showSuccess(`Task moved ${direction}`);
                setTimeout(() => this.loadTasks(), 300);
            } else {
                console.error("❌ Reorder failed:", result.error);
                this.showError(result.error || "Failed to reorder task");
            }
        } catch (error) {
            console.error("❌ Network error:", error);
            this.showError("Connection error - make sure Node.js API is running");
        }
    }
}

// Initialize enhanced kanban board
window.initializeEnhancedKanban = function(projectId) {
    window.enhancedKanbanBoard = new EnhancedKanbanBoard(projectId);
};