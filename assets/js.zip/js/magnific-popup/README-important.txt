Added custom code in line #373
To fix Call Stack Exceeded error.